package com.ticketsys;


import org.bson.types.ObjectId;
import com.mongodb.client.*;
import org.bson.Document;
import com.sun.net.httpserver.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.InetSocketAddress;

import com.ticketsys.model.Cliente;
import com.ticketsys.model.Evento;
import com.ticketsys.model.Ingresso;
import com.ticketsys.model.Reserva;

public class MainServer {

    static MongoClient mongo = MongoClients.create(
        "mongodb://DaniloArroio:2030@ac-s6nd2a8-shard-00-00.ypuuw7n.mongodb.net:27017,"
      + "ac-s6nd2a8-shard-00-01.ypuuw7n.mongodb.net:27017,"
      + "ac-s6nd2a8-shard-00-02.ypuuw7n.mongodb.net:27017/?ssl=true&replicaSet=atlas-8rwybd-shard-0&authSource=admin&appName=Cluster0"
    );

    static MongoDatabase db = mongo.getDatabase("ticketsys");

    public static void main(String[] args) throws Exception {

        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

     server.createContext("/cadastro", ex -> {

    ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
    ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

    if ("OPTIONS".equals(ex.getRequestMethod())) {
        ex.sendResponseHeaders(204, -1);
        return;
    }

    if ("GET".equals(ex.getRequestMethod())) {
        String r = "endpoint cadastro OK";
        ex.sendResponseHeaders(200, r.length());
        ex.getResponseBody().write(r.getBytes());
        ex.close();
        return;
    }

    if ("POST".equals(ex.getRequestMethod())) {

        String body = new String(ex.getRequestBody().readAllBytes());
        JSONObject j = new JSONObject(body);

       String email = j.getString("email");

Cliente cliente = new Cliente(

    email,
    j.getString("senha"),

    email.equals("ADMIN")
        ? "ADMIN"
        : "USER"
);
        Document user = new Document();
        
        user.append("email", cliente.getEmail());
        user.append("senha", cliente.getSenha());
        user.append("tipo", cliente.getTipo());

db.getCollection("users").insertOne(user);

        String r = "ok";
        ex.sendResponseHeaders(200, r.length());
        ex.getResponseBody().write(r.getBytes());
        ex.close();
    }
});
        server.createContext("/login", ex -> {

    ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
    ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

    if ("OPTIONS".equals(ex.getRequestMethod())) {
        ex.sendResponseHeaders(204, -1);
        return;
    }

    if ("POST".equals(ex.getRequestMethod())) {

        String body = new String(ex.getRequestBody().readAllBytes());
        JSONObject j = new JSONObject(body);

        String email = j.getString("email");
        String senha = j.getString("senha");

        Document user = db.getCollection("users")
            .find(new Document("email", email)).first();

        JSONObject response = new JSONObject();

        if (user != null && user.getString("senha").equals(senha)) {

            response.put("ok", true);
            response.put("tipo", user.getString("tipo"));

        } else {
            response.put("ok", false);
        }

        String r = response.toString();

        ex.sendResponseHeaders(200, r.length());
        ex.getResponseBody().write(r.getBytes());
        ex.close();
    }
});

        server.createContext("/salvar", ex -> {

    ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
    ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

    if ("OPTIONS".equals(ex.getRequestMethod())) {
        ex.sendResponseHeaders(204, -1);
        return;
    }

    if ("POST".equals(ex.getRequestMethod())) {

        String body =
            new String(ex.getRequestBody().readAllBytes());

        JSONObject j = new JSONObject(body);

        String nome = j.getString("nome");
        String tipo = j.getString("tipo");
        String eventoNome = j.getString("evento");
        double valor = j.getDouble("valor");

        Document evento = db.getCollection("eventos")
            .find(new Document("nome", eventoNome))
            .first();

        JSONObject response = new JSONObject();

        if (evento == null) {

            response.put("ok", false);
            response.put("msg", "Evento não encontrado");

        } else {

            int quantidade =
                evento.getInteger("quantidade");

            if (quantidade <= 0) {

                response.put("ok", false);
                response.put("msg", "Ingressos esgotados");

            } else {

                quantidade--;

                db.getCollection("eventos").updateOne(

                    new Document("nome", eventoNome),

                    new Document("$set",new Document("quantidade", quantidade))
                );

                Ingresso ingresso = new Ingresso(
                    nome,
                    eventoNome,
                    valor
                );

                Document compra = new Document();

                compra.append("id", ingresso.getId());
                compra.append("cliente", ingresso.getCliente());
                compra.append("evento", ingresso.getEvento());
                compra.append("valor", ingresso.getValor());
                compra.append("status", ingresso.getStatus());

                db.getCollection("ingressos").insertOne(compra);
                response.put("ok", true);
                response.put("msg", "Compra realizada");
            }
        }

        String r = response.toString();

        ex.sendResponseHeaders(200, r.length());

        ex.getResponseBody().write(r.getBytes());

        ex.close();
    }
});

       server.createContext("/listar", ex -> {

         ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
         ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, OPTIONS");
         ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

         if ("OPTIONS".equals(ex.getRequestMethod())) {
             ex.sendResponseHeaders(204, -1);
             return;
         }
     
         if ("GET".equals(ex.getRequestMethod())) {

             StringBuilder json = new StringBuilder("[");
             for (Document d : db.getCollection("ingressos").find()) {
                 json.append(new JSONObject(d).toString()).append(",");
             }
             if (json.length() > 1) json.setLength(json.length() - 1);
             json.append("]");
         
             String r = json.toString();
             ex.sendResponseHeaders(200, r.length());
             ex.getResponseBody().write(r.getBytes());
             ex.close();
         }  
       });
        
       server.createContext("/evento", ex -> {

    ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
    ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

    if ("OPTIONS".equals(ex.getRequestMethod())) {
        ex.sendResponseHeaders(204, -1);
        return;
    }

    if ("POST".equals(ex.getRequestMethod())) {

        String body = new String(ex.getRequestBody().readAllBytes());

        JSONObject j = new JSONObject(body);

       Evento eventoObj = new Evento(

        j.getString("nome"),
        j.getString("horario"),
        j.getString("local"),
        j.getDouble("preco"),
Integer.parseInt(j.get("quantidade").toString())      );

        Document evento = new Document();

        evento.append("nome", eventoObj.getNome());
        evento.append("horario", eventoObj.getHorario());
        evento.append("local", eventoObj.getLocal());
        evento.append("preco", eventoObj.getPreco());
        evento.append("quantidade", eventoObj.getQuantidade());

        db.getCollection("eventos").insertOne(evento);

        String response = "Evento cadastrado";

        ex.sendResponseHeaders(200, response.length());

        ex.getResponseBody().write(response.getBytes());

        ex.close();
      }
    });
        
    server.createContext("/eventos", ex -> {

    ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");

    JSONArray array = new JSONArray();

    MongoCursor<Document> cursor =
        db.getCollection("eventos").find().iterator();

    while (cursor.hasNext()) {

        Document doc = cursor.next();

        JSONObject obj = new JSONObject();
        obj.put("quantidade",doc.getInteger("quantidade"));
        obj.put("nome", doc.getString("nome"));
        obj.put("horario", doc.getString("horario"));
        obj.put("local", doc.getString("local"));
        obj.put("preco", doc.getDouble("preco"));
        array.put(obj);
    }

    String response = array.toString();

    ex.sendResponseHeaders(200, response.length());

    ex.getResponseBody().write(response.getBytes());

    ex.close();
});

server.start();

System.out.println("SERVIDOR RODANDO NA PORTA 8080");
  
    } 

}

