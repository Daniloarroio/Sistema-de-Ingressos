package com.ticketsys.model;

public class Evento {

    private String nome;
    private String horario;
    private String local;
    private double preco;
    private int quantidade;

    public Evento(
        String nome,
        String horario,
        String local,
        double preco,
        int quantidade
    ) {

        this.nome = nome;
        this.horario = horario;
        this.local = local;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    public String getNome() {
        return nome;
    }

  

    public String getHorario() {
        return horario;
    }

    public String getLocal() {
        return local;
    }

    public double getPreco() {
        return preco;
    }

    public int getQuantidade() {
        return quantidade;
    }
}