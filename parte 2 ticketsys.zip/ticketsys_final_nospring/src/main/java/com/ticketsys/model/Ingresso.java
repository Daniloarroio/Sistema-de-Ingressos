package com.ticketsys.model;

import java.util.UUID;

public class Ingresso {

    private String id;
    private String cliente;
    private String evento;
    private double valor;
    private String status;

    public Ingresso(
        String cliente,
        String evento,
        double valor
    ) {

        this.id = UUID.randomUUID().toString();

        this.cliente = cliente;
        this.evento = evento;
        this.valor = valor;

        this.status = "RESERVADO";
    }

    public String getId() {
        return id;
    }

    public String getCliente() {
        return cliente;
    }

    public String getEvento() {
        return evento;
    }

    public double getValor() {
        return valor;
    }

    public String getStatus() {
        return status;
    }
}