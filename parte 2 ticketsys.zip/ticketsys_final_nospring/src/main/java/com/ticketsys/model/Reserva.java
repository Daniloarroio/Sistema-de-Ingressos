package com.ticketsys.model;

public class Reserva {
    
}
