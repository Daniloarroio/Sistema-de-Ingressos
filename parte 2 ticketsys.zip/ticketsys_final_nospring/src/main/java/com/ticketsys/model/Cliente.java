package com.ticketsys.model;

public class Cliente {

    private String email;
    private String senha;
    private String tipo;

    public Cliente(
        String email,
        String senha,
        String tipo
    ) {

        this.email = email;
        this.senha = senha;
        this.tipo = tipo;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public String getTipo() {
        return tipo;
    }
}