let evento = "";
let tipo = "Normal";

window.onload = function () {
    let user = localStorage.getItem("user");

    if (!user) {
        window.location = "login.html"; 
    }

    let campoUser = document.getElementById("user");

if (campoUser) {
    campoUser.innerText = user;
}

     if (document.getElementById("lista")) {
        listar();
    }


    if (document.getElementById("eventos")) {
        listarEventosCards();
    }
};

function logout() {
    localStorage.removeItem("user");
    window.location = "login.html";
}

function selecionarEvento(el, nome) {
    evento = nome;
    document.getElementById("eventoSelecionado").innerText = nome;

    document.querySelectorAll(".card").forEach(c => c.classList.remove("ativo"));
    el.classList.add("ativo");
}

function setTipo(el, t) {
    tipo = t;

    document.querySelectorAll(".tipos button").forEach(b => b.classList.remove("ativo"));
    el.classList.add("ativo");

    atualizarPreco();
}

function atualizarPreco() {
    let base = parseFloat(document.getElementById("setor").value);
    let final = base;

    if (tipo === "VIP") final = base * 1.5;
    if (tipo === "Meia") final = base / 2;

    document.getElementById("preco").innerText = "R$ " + final;
}

async function comprar() {
    let nome = document.getElementById("nome").value;
    let valor = parseFloat(document.getElementById("preco").innerText.replace("R$ ", ""));

    await fetch("http://localhost:8080/salvar", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ nome, tipo, evento, valor })
    });

    listar();
}

async function listar() {
    let res = await fetch("http://127.0.0.1:8080/listar");
    let dados = await res.json();

    let lista = document.getElementById("lista");
    lista.innerHTML = "";

    dados.forEach(item => {

        let div = document.createElement("div");
        div.className = "item";

        div.innerHTML = `
    <b>${item.cliente}</b>
    - ${item.evento}
    - R$ ${item.valor}
    - ${item.status}
        <button onclick="abrirQR('${item.cliente}','${item.evento}')">
        QRCode
    </button>

`;

        lista.appendChild(div);
    });
}

async function cadastrarEvento() {

    let nome = document.getElementById("nomeEvento").value;
    let horario = document.getElementById("horarioEvento").value;
    let local = document.getElementById("localEvento").value;
    let preco = parseFloat(document.getElementById("precoEvento").value);
    let quantidade = parseInt(document.getElementById("quantidadeEvento").value);

    await fetch("http://localhost:8080/evento", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({
            nome,
            horario,
            local,
            preco,
            quantidade
        })
    });

    alert("Evento cadastrado!");

    listarEventosCards();
}


async function listarEventosCards() {

    let res = await fetch("http://localhost:8080/eventos");

    let dados = await res.json();

    let container = document.getElementById("eventos");

    let template = document.getElementById("templateEvento");

    container.innerHTML = "";

    dados.forEach(item => {

        let clone = template.content.cloneNode(true);

        clone.querySelector(".nomeEvento").innerText = item.nome;

        clone.querySelector(".localEvento").innerText = item.local;

        clone.querySelector(".horarioEvento").innerText = item.horario;

        clone.querySelector(".precoEvento").innerText = item.preco;

        clone.querySelector(".quantidadeEvento").innerText =
            item.quantidade + " ingressos";

            clone.querySelector(".cardEvento").onclick = function () {

         evento = item.nome;

         document.getElementById("eventoSelecionado").innerText =
          item.nome;
            }

        container.appendChild(clone);

    });
}

function abrirQR(nome, evento) {

    let dados =
    "https://ticketsys.com/ingresso?cliente="
    + encodeURIComponent(nome)
    + "&evento="
    + encodeURIComponent(evento);

    let link =
    "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data="
    + encodeURIComponent(dados);

    document.getElementById("imgQR").src = link;

    document.getElementById("modalQR").style.display = "flex";

    
}
function fecharQR() {

    document.getElementById("modalQR").style.display = "none";
}