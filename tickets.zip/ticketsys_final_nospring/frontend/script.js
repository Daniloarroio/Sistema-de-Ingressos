let evento = "";
let tipo = "Normal";

window.onload = function () {
    let user = localStorage.getItem("user");

    if (!user) {
        window.location = "login.html"; 
    }

    document.getElementById("user").innerText = user;

    listar();
};

function logout() {
    localStorage.removeItem("user");
    window.location = "login.html";
}

function selecionarEvento(el, nome) {
    evento = nome;
    document.getElementById("eventoSelecionado").innerText = nome;

    document.querySelectorAll(".card").forEach(c => c.classList.remove("ativo"));
    el.classList.add("ativo");
}

function setTipo(el, t) {
    tipo = t;

    document.querySelectorAll(".tipos button").forEach(b => b.classList.remove("ativo"));
    el.classList.add("ativo");

    atualizarPreco();
}

function atualizarPreco() {
    let base = parseFloat(document.getElementById("setor").value);
    let final = base;

    if (tipo === "VIP") final = base * 1.5;
    if (tipo === "Meia") final = base / 2;

    document.getElementById("preco").innerText = "R$ " + final;
}

async function comprar() {
    let nome = document.getElementById("nome").value;
    let valor = parseFloat(document.getElementById("preco").innerText.replace("R$ ", ""));

    await fetch("http://localhost:8080/salvar", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ nome, tipo, evento, valor })
    });

    listar();
}

async function listar() {
    let res = await fetch("http://127.0.0.1:8080/listar");
    let dados = await res.json();

    let lista = document.getElementById("lista");
    lista.innerHTML = "";

    dados.forEach(item => {

        let div = document.createElement("div");
        div.className = "item";

        div.innerHTML = `
            <b>${item.nome}</b> - ${item.tipo} - ${item.evento} - R$ ${item.valor}
        `;

        lista.appendChild(div);
    });
}


listar();