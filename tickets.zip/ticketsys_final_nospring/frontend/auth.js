async function cadastrar() {
    console.log("clicou");

    let email = document.getElementById("email").value;
    let senha = document.getElementById("senha").value;

    try {
        let res = await fetch("http://127.0.0.1:8080/cadastro", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ email, senha })
        });

        console.log("resposta chegou");

        alert("Cadastro realizado!");
        
        setTimeout(() => {
            window.location.href = "login.html";
        }, 500);

    } catch (erro) {
        console.error("ERRO:", erro);

        alert("Erro no servidor, mas indo para login...");
        
        window.location.href = "login.html";
    }
}

async function login() {
    let email = document.getElementById("email").value;
    let senha = document.getElementById("senha").value;

    let res = await fetch("http://localhost:8080/login", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ email, senha })
    });

    let ok = await res.text();

    if (ok === "true") {
        localStorage.setItem("user", email);
        window.location = "home.html";
    } else {
        alert("Login inválido");
    }
}

function irCadastro() {
    window.location = "cadastro.html";
}

function irLogin() {
    window.location = "login.html";
}