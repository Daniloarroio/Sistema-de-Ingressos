package com.ticketsys;

import org.bson.types.ObjectId;
import com.mongodb.client.*;
import org.bson.Document;
import com.sun.net.httpserver.*;
import org.json.JSONObject;

import java.io.*;
import java.net.InetSocketAddress;

public class MainServer {

    static MongoClient mongo = MongoClients.create(
        "mongodb://DaniloArroio:2030@ac-s6nd2a8-shard-00-00.ypuuw7n.mongodb.net:27017,"
      + "ac-s6nd2a8-shard-00-01.ypuuw7n.mongodb.net:27017,"
      + "ac-s6nd2a8-shard-00-02.ypuuw7n.mongodb.net:27017/?ssl=true&replicaSet=atlas-8rwybd-shard-0&authSource=admin&appName=Cluster0"
    );

    static MongoDatabase db = mongo.getDatabase("ticketsys");

    public static void main(String[] args) throws Exception {

        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

     server.createContext("/cadastro", ex -> {

    ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
    ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

    if ("OPTIONS".equals(ex.getRequestMethod())) {
        ex.sendResponseHeaders(204, -1);
        return;
    }

    if ("GET".equals(ex.getRequestMethod())) {
        String r = "endpoint cadastro OK";
        ex.sendResponseHeaders(200, r.length());
        ex.getResponseBody().write(r.getBytes());
        ex.close();
        return;
    }

    if ("POST".equals(ex.getRequestMethod())) {

        String body = new String(ex.getRequestBody().readAllBytes());
        JSONObject j = new JSONObject(body);

        Document user = new Document("email", j.getString("email"))
                .append("senha", j.getString("senha"));

        db.getCollection("users").insertOne(user);

        String r = "ok";
        ex.sendResponseHeaders(200, r.length());
        ex.getResponseBody().write(r.getBytes());
        ex.close();
    }
});
        server.createContext("/login", ex -> {

        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

         if ("OPTIONS".equals(ex.getRequestMethod())) {
            ex.sendResponseHeaders(204, -1);
            return;
           }

        if ("POST".equals(ex.getRequestMethod())) {

            String body = new String(ex.getRequestBody().readAllBytes());
            JSONObject j = new JSONObject(body);

            Document user = db.getCollection("users")
                .find(new Document("email", j.getString("email"))).first();

            boolean ok = false;
            if (user != null && user.getString("senha").equals(j.getString("senha"))) {
                ok = true;
            }

            String r = String.valueOf(ok);
            ex.sendResponseHeaders(200, r.length());
             ex.getResponseBody().write(r.getBytes());
            ex.close();
         }
        });

        server.createContext("/salvar", ex -> {

         ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
         ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

         if ("OPTIONS".equals(ex.getRequestMethod())) {
            ex.sendResponseHeaders(204, -1);
            return;
        }

        if ("POST".equals(ex.getRequestMethod())) {

        String body = new String(ex.getRequestBody().readAllBytes());
        JSONObject j = new JSONObject(body);

        Document doc = new Document("nome", j.getString("nome"))
                .append("tipo", j.getString("tipo"))
                .append("evento", j.getString("evento"))
                .append("valor", j.getDouble("valor"));

        db.getCollection("ticketsys").insertOne(doc);

        String r = "ok";
        ex.sendResponseHeaders(200, r.length());
        ex.getResponseBody().write(r.getBytes());
        ex.close();
        }
        });

       server.createContext("/listar", ex -> {

         ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
         ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, OPTIONS");
         ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

         if ("OPTIONS".equals(ex.getRequestMethod())) {
             ex.sendResponseHeaders(204, -1);
             return;
         }
     
         if ("GET".equals(ex.getRequestMethod())) {

             StringBuilder json = new StringBuilder("[");
             for (Document d : db.getCollection("ticketsys").find()) {
                 json.append(new JSONObject(d).toString()).append(",");
             }
             if (json.length() > 1) json.setLength(json.length() - 1);
             json.append("]");
         
             String r = json.toString();
             ex.sendResponseHeaders(200, r.length());
             ex.getResponseBody().write(r.getBytes());
             ex.close();
         }
       });
        
        
  
    } 

}
